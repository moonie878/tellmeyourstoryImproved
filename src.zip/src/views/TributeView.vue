<template>
  <main class="tribute-page">

    <!-- ── Hero ─────────────────────────────────────────────────────────── -->
    <section class="tribute-hero">
      <div class="tribute-hero-inner">
        <div class="hero-badge">Tell Me Your Story</div>
        <h1 class="hero-title">
          Create a tribute<br />
          <em>they'll carry forever</em>
        </h1>
        <p class="hero-sub">
          Upload photos and video clips, add music, 
          and create a beautiful memorial video in minutes — free to preview, £19.99 to download.
        </p>
        <div class="hero-trust">
          <span>✦ No account needed</span>
          <span>✦ Preview free</span>
          <span>✦ Download for £19.99</span>
        </div>
      </div>
    </section>

    <!-- ── Builder ───────────────────────────────────────────────────────── -->
    <section class="builder-section">
      <div class="builder-inner">

        <!-- Step indicators -->
        <div class="steps-bar">
          <div
            v-for="(s, i) in steps"
            :key="s.id"
            class="step-item"
            :class="{
              'step-active': currentStep === i,
              'step-done': currentStep > i,
              'step-idle': currentStep < i,
            }"
            @click="currentStep > i ? currentStep = i : null"
          >
            <div class="step-dot">
              <span v-if="currentStep > i">✓</span>
              <span v-else>{{ i + 1 }}</span>
            </div>
            <span class="step-label">{{ s.label }}</span>
          </div>
        </div>

        <!-- ── Step 0 — Details ─────────────────────────────────────────── -->
        <div v-if="currentStep === 0" class="builder-card">
          <h2 class="card-title">About them</h2>
          <p class="card-sub">Tell us who this tribute is for.</p>

          <div class="field-group">
            <label class="field-label">Their full name <span class="required">*</span></label>
            <input v-model="form.name" type="text" placeholder="e.g. Margaret Eleanor Griffiths" class="field-input" maxlength="80" />
          </div>

          <div class="field-row">
            <div class="field-group">
              <label class="field-label">Year of birth</label>
              <input v-model="form.birthYear" type="text" placeholder="e.g. 1942" class="field-input" maxlength="4" />
            </div>
            <div class="field-group">
              <label class="field-label">Year of passing</label>
              <input v-model="form.deathYear" type="text" placeholder="e.g. 2024" class="field-input" maxlength="4" />
            </div>
          </div>

          <div class="field-group">
            <label class="field-label">
              A tribute in their memory
              <span class="field-optional">(optional — up to 200 words)</span>
            </label>
            <textarea v-model="form.tribute" rows="4" placeholder="A short tribute that will appear as a beautiful quote slide in the video…" class="field-input field-textarea" maxlength="1200"></textarea>
            <p class="field-count">{{ wordCount }} / 200 words</p>
          </div>

          <button @click="nextStep" :disabled="!form.name.trim()" class="btn-primary">
            Continue — add photos →
          </button>
        </div>

        <!-- ── Step 1 — Photos ──────────────────────────────────────────── -->
      <!-- ── Step 1 — Photos & Videos ────────────────────────────────────────── -->
<div v-else-if="currentStep === 1" class="builder-card">
  <h2 class="card-title">Photos & videos</h2>
  <p class="card-sub">
    Upload photos and short video clips. Drag to reorder — they'll appear in this order in your tribute.
  </p>

  <!-- Upload zone -->
  <div
    class="upload-zone"
    :class="{ 'upload-zone-hover': isDragging }"
    @dragover.prevent="isDragging = true"
    @dragleave="isDragging = false"
    @drop.prevent="onDrop"
  >
    <div class="upload-zone-content">
      <span class="upload-icon">📷</span>
      <p class="upload-text">Drop photos or videos here</p>
      <p class="upload-hint">or choose what to add:</p>
      <div class="upload-btn-row">
        <label class="upload-type-btn" :class="photoCount >= MAX_PHOTOS ? 'upload-type-btn-disabled' : ''">
          📷 Add photos {{ photoCount > 0 ? `(${photoCount}/${MAX_PHOTOS})` : '' }}
          <input
            ref="fileInputRef"
            type="file"
            accept="image/*"
            multiple
            class="hidden"
            :disabled="photoCount >= MAX_PHOTOS"
            @change="onFileSelect"
          />
        </label>
        <label class="upload-type-btn" :class="videoCount >= MAX_VIDEOS ? 'upload-type-btn-disabled' : ''">
          🎬 Add video clip {{ videoCount > 0 ? `(${videoCount}/${MAX_VIDEOS})` : '' }}
          <input
            type="file"
            accept="video/mp4,video/mov,video/quicktime,video/*"
            class="hidden"
            :disabled="videoCount >= MAX_VIDEOS"
            @change="onVideoSelect"
          />
        </label>
      </div>
      <p class="upload-hint">Up to 30 photos + 5 video clips · Videos max 30 seconds each</p>
    </div>
  </div>

  <!-- Media grid -->
  <div v-if="form.media.length > 0" class="photo-grid">
    <div
      v-for="(item, i) in form.media"
      :key="i"
      class="photo-thumb"
      :class="{ 'photo-thumb-first': i === 0, 'photo-thumb-video': item.type === 'video' }"
    >
      <!-- Photo -->
      <img
        v-if="item.type === 'photo'"
        :src="item.src"
        :alt="`Photo ${i + 1}`"
        class="photo-img"
        loading="lazy"
      />

      <!-- Video -->
      <div v-else class="video-thumb-inner">
        <video
          :src="item.previewUrl"
          class="photo-img"
          muted
          preload="metadata"
        />
        <div class="video-badge">🎬 Video</div>
      </div>

      <!-- Controls overlay -->
      <div class="photo-overlay">
        <button v-if="i > 0" @click="moveMedia(i, -1)" class="photo-btn">←</button>
        <button @click="removeMedia(i)" class="photo-btn photo-btn-remove">✕</button>
        <button v-if="i < form.media.length - 1" @click="moveMedia(i, 1)" class="photo-btn">→</button>
      </div>

      <div v-if="i === 0" class="photo-first-badge">Cover</div>
    </div>
  </div>

  <p v-if="form.media.length === 0" class="photo-empty">
    No photos or videos added yet — upload at least one photo to continue.
  </p>

  <div class="media-counts" v-if="form.media.length > 0">
    <span>{{ photoCount }} photo{{ photoCount !== 1 ? 's' : '' }}</span>
    <span v-if="videoCount > 0">· {{ videoCount }} video clip{{ videoCount !== 1 ? 's' : '' }}</span>
  </div>

  <div class="btn-row">
    <button @click="currentStep--" class="btn-secondary">← Back</button>
    <button
      @click="nextStep"
      :disabled="photoCount === 0"
      class="btn-primary"
    >
      Continue — choose music →
    </button>
  </div>
</div>

        <!-- ── Step 2 — Music & Style ────────────────────────────────────── -->
        <div v-else-if="currentStep === 2" class="builder-card">
          <h2 class="card-title">Music & style</h2>
          <p class="card-sub">Choose the mood and pace of your tribute.</p>

          <div class="field-group">
            <label class="field-label">Background music</label>
            <p class="field-hint">Click a track to select it. Hit the play button to preview.</p>
            <div class="option-grid">
              <div
                v-for="(track, key) in MUSIC_TRACKS"
                :key="key"
                class="option-card"
                :class="form.musicTrack === key ? 'option-active' : 'option-idle'"
                @click="selectTrack(key as TributeMusicTrack)"
              >
                <div class="option-top">
                  <span class="option-emoji">{{ track.emoji }}</span>
                  <button v-if="key !== 'silent' && key !== 'custom'" @click.stop="togglePreview(key as TributeMusicTrack)" class="preview-btn" :class="playingTrack === key ? 'preview-btn-playing' : ''">
                    <span v-if="playingTrack === key">■</span>
                    <span v-else>▶</span>
                  </button>
                </div>
                <p class="option-label">{{ track.label }}</p>
                <p class="option-desc">{{ track.description }}</p>
                <div v-if="playingTrack === key" class="playing-bar">
                  <span></span><span></span><span></span><span></span>
                </div>
              </div>
            </div>
          </div>

          <div v-if="form.musicTrack === 'custom'" class="field-group">
            <label class="field-label">Upload your music (MP3)</label>
            <label class="music-upload-btn">
  <input type="file" accept=".mp3,.m4a,.wav,.aac,audio/*" class="hidden" @change="onMusicUpload" />
  {{ form.musicFile ? `✓ ${form.musicFile.name}` : '+ Upload MP3' }}
</label>
<p style="font-size: 11px; color: #A8A29E; margin-top: 6px;">Supports MP3, M4A, WAV · Max 25MB</p>
          </div>

          <div class="field-group">
            <label class="field-label">Time per photo</label>
            <div class="duration-row">
              <button v-for="d in durations" :key="d.value" @click="form.slideDuration = d.value as TributeSlideDuration" class="duration-btn" :class="form.slideDuration === d.value ? 'duration-active' : 'duration-idle'">
                <span class="duration-num">{{ d.label }}</span>
                <span class="duration-hint">{{ d.hint }}</span>
              </button>
            </div>
          </div>

          <div class="field-group">
            <label class="field-label">Transition between photos</label>
            <div class="transition-row">
              <button v-for="t in transitions" :key="t.value" @click="form.transition = t.value as TributeTransition" class="transition-btn" :class="form.transition === t.value ? 'transition-active' : 'transition-idle'">
                <div class="transition-preview">
                  <div v-if="t.value === 'cut'" class="t-cut"><div class="t-half-l"></div><div class="t-half-r"></div></div>
                  <div v-else-if="t.value === 'fade'" class="t-fade"></div>
                  <div v-else class="t-slow-fade"></div>
                </div>
                <p class="transition-label">{{ t.label }}</p>
                <p class="transition-hint">{{ t.hint }}</p>
              </button>
            </div>
          </div>

          <div class="estimate-bar">
            <span>🎬 Estimated video length:</span>
            <span class="estimate-value">{{ estimatedLength }}</span>
          </div>

          <div class="btn-row">
            <button @click="currentStep--" class="btn-secondary">← Back</button>
            <button @click="nextStep" class="btn-primary">Preview my tribute →</button>
          </div>
        </div>

        <!-- ── Step 3 — Preview & Export ─────────────────────────────────── -->
        <div v-else-if="currentStep === 3" class="builder-card">
          <h2 class="card-title">Your tribute is ready</h2>
          <p class="card-sub">
            Preview your tribute with a watermark for free, or download
            the full clean version for £19.99.
          </p>

          <!-- Summary -->
          <div class="summary-card">
            <div class="summary-row"><span class="summary-label">Name</span><span class="summary-value">{{ form.name }}</span></div>
            <div v-if="form.birthYear || form.deathYear" class="summary-row">
              <span class="summary-label">Dates</span>
              <span class="summary-value">{{ [form.birthYear, form.deathYear].filter(Boolean).join(' — ') }}</span>
            </div>
           <div class="summary-row">
  <span class="summary-label">Photos</span>
  <span class="summary-value">{{ photoCount }} photo{{ photoCount !== 1 ? 's' : '' }}</span>
</div>
<div v-if="videoCount > 0" class="summary-row">
  <span class="summary-label">Video clips</span>
  <span class="summary-value">{{ videoCount }} clip{{ videoCount !== 1 ? 's' : '' }}</span>
</div>
            <div class="summary-row"><span class="summary-label">Music</span><span class="summary-value">{{ MUSIC_TRACKS[form.musicTrack].label }}</span></div>
            <div class="summary-row"><span class="summary-label">Duration</span><span class="summary-value">~{{ estimatedLength }}</span></div>
          </div>

          <!-- Turnstile -->
          <div ref="turnstileRef" class="turnstile-wrap"></div>
          <p v-if="turnstileError" class="error-text">Please complete the security check before continuing.</p>

          <!-- Progress -->
          <div v-if="isGenerating" class="progress-section">
            <div class="progress-bar-wrap">
              <div class="progress-bar-fill" :style="{ width: `${progress}%` }"></div>
            </div>
            <div class="progress-row">
              <span class="progress-label">{{ progressLabel }}</span>
              <span class="progress-pct">{{ progress }}%</span>
            </div>
            <p class="progress-note">
              {{ isBuildingForPurchase
                ? 'Making your video first — you only pay once it\'s ready. Please keep this window open 💛'
                : 'This takes a few minutes — please keep this window open 💛' }}
            </p>
          </div>

          <p v-if="error" class="error-text">{{ error }}</p>

          <!-- Payment pending state -->
<div v-if="showingPaymentPending && !isGenerating" class="payment-pending-card">
  <div class="payment-pending-icon">💳</div>
  <h3 class="payment-pending-title">Waiting for payment…</h3>
  <p class="payment-pending-desc">
    Complete your payment in the other tab. Your tribute will start
    generating automatically as soon as payment is confirmed —
    you don't need to do anything else.
  </p>

  <div v-if="isVerifying" class="verifying-row">
    <div class="spinner"></div>
    <span>Payment confirmed — generating your tribute…</span>
  </div>

  <button
    @click="reopenPayment"
    class="btn-primary"
    style="margin-top: 16px;"
  >
    ← Reopen payment tab
  </button>

  <button
    @click="cancelPayment"
    class="btn-back-link"
    style="margin-top: 12px; display: block;"
  >
    Cancel — start over
  </button>
</div>

          <!-- Normal action buttons -->
          <div v-if="!isGenerating && !showingPaymentPending" class="export-buttons">
            <button @click="handlePreview" class="btn-preview">
              <span class="btn-icon">👁</span>
              <div>
                <p class="btn-main-label">Preview (free)</p>
                <p class="btn-sub-label">Watermarked · Downloads instantly</p>
              </div>
            </button>

            <button
  @click="(isTier4 || hasPaid) ? handleFreeDownload() : handlePurchase()"
  class="btn-purchase"
>
  <span class="btn-icon">⬇</span>
  <div>
    <p class="btn-main-label">
      {{ isTier4 || hasPaid ? 'Download full video' : 'Download full video — £19.99' }}
    </p>
    <p class="btn-sub-label">
      {{ isTier4 ? 'Included in your Full Collection plan ✦'
        : hasPaid ? 'Already purchased — re-generate free ✦'
        : 'We make it first — you only pay once it\'s ready' }}
    </p>
  </div>
</button>
          </div>

          <div v-if="!showingPaymentPending" class="trust-row">
            <span>🔒 Secure payment via Stripe</span>
            <span>·</span>
            <span>No account required</span>
            <span>·</span>
            <span>Instant download after payment</span>
          </div>

          <button @click="currentStep--" class="btn-back-link">← Edit your tribute</button>
        </div>

      </div>
    </section>

    <!-- ── Why section ───────────────────────────────────────────────────── -->
    <section class="why-section">
      <div class="why-inner">
        <p class="why-eyebrow">Tell Me Your Story</p>
        <h2 class="why-title">A beautiful way to honour a life</h2>
        <div class="why-grid">
          <div class="why-card">
  <span class="why-icon">📸</span>
  <p class="why-card-title">Photos & video clips</p>
  <p class="why-card-desc">Up to 30 photos and 5 video clips — arranged in any order, flowing beautifully with elegant transitions.</p>
</div>
          <div class="why-card"><span class="why-icon">🎵</span><p class="why-card-title">Music that fits</p><p class="why-card-desc">Choose from curated gentle tracks or upload your own music that was meaningful to them.</p></div>
          <div class="why-card"><span class="why-icon">💛</span><p class="why-card-title">Their words</p><p class="why-card-desc">Add a tribute that becomes a beautiful quote slide woven through the video.</p></div>
          <div class="why-card"><span class="why-icon">🎬</span><p class="why-card-title">Full HD MP4</p><p class="why-card-desc">Download and share with family, play at a memorial service, or keep it forever.</p></div>
        </div>
        <div class="upsell-card">
          <p class="upsell-eyebrow">Want more than a tribute video?</p>
          <h3 class="upsell-title">Capture their full life story with Tell Me Your Story</h3>
          <p class="upsell-desc">100 guided questions across 10 chapters. Every answer turns into a beautifully designed keepsake book — a complete record of their life, in their own words.</p>
          <router-link to="/register" class="upsell-btn">Start capturing their story — it's free →</router-link>
        </div>
      </div>
    </section>

    <!-- ── Payment modal ─────────────────────────────────────────────────── -->
    <TributePaymentModal
      :open="showPaymentModal"
      :name="form.name"
      @close="showPaymentModal = false"
      @payment-opened="onPaymentOpened"
    />

  </main>
</template>

<script setup lang="ts">
import { ref, computed, watch, nextTick, onMounted, onUnmounted } from 'vue'
import { useTributeVideo, MUSIC_TRACKS } from '../composables/useTributeVideo'
import TributePaymentModal from '../components/tribute/TributePaymentModal.vue'
import type { TributeMusicTrack, TributeTransition, TributeSlideDuration, TributeOptions, TributeMediaItem, TributeResult } from '../composables/useTributeVideo'
import { supabase } from '../lib/supabase'
import { track } from '../lib/analytics'
import { useSeo } from '../composables/useSeo'


useSeo({
  title: 'Create a Memorial Tribute Video | Tell Me Your Story',
  description: 'Create a beautiful memorial tribute video in minutes. Upload photos, Videos add music, and honour a loved one\'s life. Free to preview — £19.99 to download.',
  canonical: 'https://tellmeyourstory.uk/tribute',
  schema: {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'WebPage',
        name: 'Memorial Tribute Video Creator',
        description: 'Create a beautiful memorial tribute video with photos and music. Free to preview, £19.99 to download.',
        url: 'https://tellmeyourstory.uk/tribute',
        publisher: {
          '@type': 'Organization',
          name: 'Tell Me Your Story',
          url: 'https://tellmeyourstory.uk',
        },
      },
      {
        '@type': 'Product',
        name: 'Memorial Tribute Video',
        description: 'A beautiful memorial video created from your photos and music. Upload up to 30 photos, choose music, and download a full HD MP4.',
        image: 'https://tellmeyourstory.uk/logo/tribute.jpeg', // ← add this
        url: 'https://tellmeyourstory.uk/tribute',
        brand: {
          '@type': 'Brand',
          name: 'Tell Me Your Story',
        },
        offers: {
          '@type': 'Offer',
          price: '19.99',
          priceCurrency: 'GBP',
          availability: 'https://schema.org/InStock',
          description: 'Full HD tribute video download. Free watermarked preview available.',
        },
      },
      {
        '@type': 'FAQPage',
        mainEntity: [
          {
            '@type': 'Question',
            name: 'How do I create a memorial tribute video?',
            acceptedAnswer: {
              '@type': 'Answer',
              text: 'Upload up to 30 photos, add a tribute message, choose background music, and preview your video for free. Download the full HD version without watermark for £19.99.',
            },
          },
          {
            '@type': 'Question',
            name: 'How much does a tribute video cost?',
            acceptedAnswer: {
              '@type': 'Answer',
              text: 'Previewing your tribute video is completely free. Downloading the full HD version without a watermark costs £19.99 — a one-time payment with no account required.',
            },
          },
          {
            '@type': 'Question',
            name: 'Can I use my own music in a tribute video?',
            acceptedAnswer: {
              '@type': 'Answer',
              text: 'Yes — you can upload your own MP3 file, or choose from a selection of gentle, curated music tracks included in the app.',
            },
          },
          {
            '@type': 'Question',
            name: 'How long does it take to create a tribute video?',
            acceptedAnswer: {
              '@type': 'Answer',
              text: 'Most tribute videos are created in under 5 minutes. Upload your photos, add a message and music, and your video is ready to preview instantly.',
            },
          },
        ],
      },
    ],
  },
})


// ── State ─────────────────────────────────────────────────────────────────────
const currentStep           = ref(0)
const isDragging            = ref(false)
const turnstileRef          = ref<HTMLElement | null>(null)
const turnstileToken        = ref('')
const turnstileError        = ref(false)
const showPaymentModal      = ref(false)
const showingPaymentPending = ref(false)
const lastPaymentUrl        = ref('')
const isTier4               = ref(false)
const isVerifying = ref(false)
const hasPaid = ref(false)

/*
  The clean video is now rendered BEFORE payment is taken and held here until
  the payment clears. Previously Stripe was charged first and generation ran
  afterwards, so a failed render meant somebody had paid £19.99 and received
  nothing. No object URL is created for it until payment is confirmed.
*/
const pendingVideo = ref<TributeResult | null>(null)
const isBuildingForPurchase = ref(false)


// ── Audio preview ─────────────────────────────────────────────────────────────
const playingTrack = ref<TributeMusicTrack | null>(null)
let previewAudio: HTMLAudioElement | null = null
let previewTimeout: ReturnType<typeof setTimeout> | null = null

function selectTrack(key: TributeMusicTrack) {
  form.value.musicTrack = key
  // Clear custom music file if switching to a curated track
  if (key !== 'custom') {
    form.value.musicFile = null
  }
  if (playingTrack.value && playingTrack.value !== key) stopPreview()
}

function togglePreview(key: TributeMusicTrack) {
  if (playingTrack.value === key) { stopPreview(); return }
  stopPreview()
  playingTrack.value = key
  previewAudio = new Audio(`/audio/${key}.mp3`)
  previewAudio.volume = 0
  previewAudio.play().catch(() => { playingTrack.value = null })
  let vol = 0
  const fadeIn = setInterval(() => {
    vol = Math.min(vol + 0.1, 0.7)
    if (previewAudio) previewAudio.volume = vol
    if (vol >= 0.7) clearInterval(fadeIn)
  }, 80)
  previewTimeout = setTimeout(() => fadeOutAndStop(), 12000)
}

function fadeOutAndStop() {
  if (!previewAudio) return
  const audio = previewAudio
  let vol = audio.volume
  const fadeOut = setInterval(() => {
    vol = Math.max(vol - 0.08, 0)
    audio.volume = vol
    if (vol <= 0) { clearInterval(fadeOut); audio.pause(); audio.src = ''; playingTrack.value = null }
  }, 80)
}

function stopPreview() {
  if (previewTimeout) { clearTimeout(previewTimeout); previewTimeout = null }
  if (previewAudio) { previewAudio.pause(); previewAudio.src = ''; previewAudio = null }
  playingTrack.value = null
}

async function handleFreeDownload() {
  if (!turnstileToken.value) { turnstileError.value = true; return }
  track('tribute_tier4_download', {
    photoCount: form.value.photos.length,
  })
  const result = await generateTribute(buildOptions(false))
  if (result) downloadTribute(result)
}

// ── Form ──────────────────────────────────────────────────────────────────────
const MAX_PHOTOS = 30
const MAX_VIDEOS = 5
const MAX_MEDIA  = MAX_PHOTOS + MAX_VIDEOS

const form = ref({
  name:          '',
  birthYear:     '',
  deathYear:     '',
  tribute:       '',
  photos:        [] as string[],        // kept for backwards compat
  media:         [] as TributeMediaItem[], // new unified list
  musicTrack:    'gentle-piano' as TributeMusicTrack,
  musicFile:     null as File | null,
  slideDuration: 5 as TributeSlideDuration,
  transition:    'fade' as TributeTransition,
  watermark:     true,
})

const videoCount = computed(() => form.value.media.filter(m => m.type === 'video').length)
const photoCount = computed(() => form.value.media.filter(m => m.type === 'photo').length)

const steps = [
  { id: 'details', label: 'Details' },
  { id: 'photos',  label: 'Photos' },
  { id: 'style',   label: 'Music & style' },
  { id: 'export',  label: 'Preview & export' },
]

const durations = [
  { value: 3, label: '3s', hint: 'Lively' },
  { value: 5, label: '5s', hint: 'Balanced' },
  { value: 8, label: '8s', hint: 'Gentle' },
]

const transitions = [
  { value: 'cut',       label: 'Cut',       hint: 'Instant switch' },
  { value: 'fade',      label: 'Fade',      hint: '1 second blend' },
  { value: 'slow-fade', label: 'Slow fade', hint: '2 second blend' },
]

// ── Composable ────────────────────────────────────────────────────────────────
const {
  isGenerating, progress, progressLabel, error,
  generateTribute, downloadTribute, estimateSeconds,
} = useTributeVideo()

// ── Computed ─────────────────────────────────────────────────────────────────
const wordCount = computed(() => {
  const words = form.value.tribute.trim().split(/\s+/).filter(Boolean)
  return Math.min(words.length, 200)
})

/*
  Counts media, not photos. The old version used form.photos, which excludes
  video clips, so the estimate was wrong for anyone who added one. Transitions
  also SHORTEN the video (slides overlap) rather than lengthening it — the old
  maths added them on.
*/
const estimatedLength = computed(() => {
  const totalSecs = Math.round(estimateSeconds(
    form.value.media.length,
    form.value.slideDuration,
    form.value.transition,
    form.value.tribute.trim().length > 0,
  ))
  const mins = Math.floor(totalSecs / 60)
  const secs = totalSecs % 60
  return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`
})

// ── Lifecycle ─────────────────────────────────────────────────────────────────
onMounted(async () => {
  if (!document.querySelector('script[src*="turnstile"]')) {
    const script = document.createElement('script')
    script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js'
    script.async = true
    script.defer = true
    document.head.appendChild(script)
  }

  const params = new URLSearchParams(window.location.search)
  if (params.get('payment') === 'success') {
    const sessionId = params.get('session_id')
    if (sessionId) {
        // Write session ID to localStorage so the original tab picks it up
      localStorage.setItem('tribute_payment_session', sessionId)
      // Close this tab — the original tab will handle the rest
      window.close()
      // If window.close() is blocked, show a message
      document.body.innerHTML = `
        <div style="font-family:sans-serif;text-align:center;padding:60px 24px;">
          <h2>Payment complete! 💛</h2>
          <p>You can close this tab and return to your tribute.</p>
        </div>
      `
    }
    return
  }

  window.addEventListener('storage', onStorageChange)

  const { data: { user } } = await supabase.auth.getUser()
  if (user) {
    const { data } = await supabase.from('user_access').select('*').eq('user_id', user.id)
    if (data) {
      const hasAllStories  = data.some((i) => i.access_type === 'story' && i.story_type === 'all')
      const hasImageExport = data.some((i) => i.access_type === 'export' && i.variant === 'with_images')
      isTier4.value = hasAllStories && hasImageExport
    }
  }
})

onUnmounted(() => {
  window.removeEventListener('storage', onStorageChange)
})

// ── Turnstile ─────────────────────────────────────────────────────────────────
watch(currentStep, async (step) => {
  if (step !== 3) return
  await nextTick()
  const renderWidget = () => {
    if (window.turnstile && turnstileRef.value) {
      window.turnstile.render(turnstileRef.value, {
        sitekey: import.meta.env.VITE_TURNSTILE_SITE_KEY,
        callback: (token: string) => { turnstileToken.value = token; turnstileError.value = false },
      })
    } else {
      setTimeout(renderWidget, 500)
    }
  }
  renderWidget()
})

// ── Navigation ────────────────────────────────────────────────────────────────
function nextStep() {
  stopPreview()
  if (currentStep.value < steps.length - 1) {
    currentStep.value++
    window.scrollTo({ top: 0, behavior: 'smooth' })

     // Track step progression
    track('tribute_step_reached', {
      step: currentStep.value,
      stepName: steps[currentStep.value].label,
    })

  }
}

function onStorageChange(event: StorageEvent) {
  if (event.key === 'tribute_payment_session' && event.newValue) {
    const sessionId = event.newValue
    localStorage.removeItem('tribute_payment_session')
    // Verify and generate automatically — no user action needed
    verifyAndGenerate(sessionId)
  }
}

// ── Photos ────────────────────────────────────────────────────────────────────


/*
  Reads one image, checks it actually decodes, and adds it.

  The old version fired off FileReader callbacks in a loop and tried to guard
  the cap inside each callback, which is why 32 photos could get in past a
  limit of 30 — the reads finished out of order. Awaiting each one makes the
  count exact.

  It also validates the image. A file that doesn't decode used to sail through
  and render as a blank white card in the finished video, and because the
  render "succeeded" the customer was still charged.
*/
function readPhoto(file: File): Promise<string | null> {
  return new Promise((resolve) => {
    const reader = new FileReader()
    reader.onerror = () => resolve(null)
    reader.onload = (e) => {
      const src = e.target?.result as string
      if (!src) return resolve(null)
      const img = new Image()
      img.onload  = () => resolve(img.naturalWidth > 0 && img.naturalHeight > 0 ? src : null)
      img.onerror = () => resolve(null)
      img.src = src
    }
    reader.readAsDataURL(file)
  })
}

async function addPhotoFiles(files: File[]) {
  let rejected = 0
  let hitCap = false

  for (const file of files) {
    if (photoCount.value >= MAX_PHOTOS || form.value.media.length >= MAX_MEDIA) { hitCap = true; break }
    const src = await readPhoto(file)
    if (!src) { rejected++; continue }
    form.value.media.push({ type: 'photo', src })
    form.value.photos.push(src)
  }

  if (hitCap)   alert(`You can add up to ${MAX_PHOTOS} photos and ${MAX_VIDEOS} video clips.`)
  if (rejected) alert(`${rejected} file${rejected > 1 ? "s couldn't be read and were" : " couldn't be read and was"} skipped.`)
}

async function onFileSelect(event: Event) {
  const input = event.target as HTMLInputElement
  if (!input.files) return
  const files = Array.from(input.files)
  input.value = ''
  await addPhotoFiles(files)
}



async function onDrop(event: DragEvent) {
  isDragging.value = false
  const files = Array.from(event.dataTransfer?.files || [])

  const videos = files.filter((f) => f.type.startsWith('video/'))
  for (const file of videos) {
    if (videoCount.value >= MAX_VIDEOS || form.value.media.length >= MAX_MEDIA) break
    if (file.size > 200 * 1024 * 1024) {
      alert(`${file.name} is too large — maximum 200MB per video clip`)
      continue
    }
    form.value.media.push({ type: 'video', file, previewUrl: URL.createObjectURL(file) })
  }

  await addPhotoFiles(files.filter((f) => f.type.startsWith('image/')))
}

function onVideoSelect(event: Event) {
  const input = event.target as HTMLInputElement
  if (!input.files) return
  
  const files = Array.from(input.files)
  
  for (const file of files) {
    if (videoCount.value >= MAX_VIDEOS) {
      alert(`Maximum ${MAX_VIDEOS} video clips allowed`)
      break
    }
    if (form.value.media.length >= MAX_MEDIA) {
      alert(`Maximum ${MAX_MEDIA} total media items allowed`)
      break
    }
    
    // Validate file type
    if (!file.type.startsWith('video/')) continue
    
    // Validate size (max 200MB per clip)
    if (file.size > 200 * 1024 * 1024) {
      alert(`${file.name} is too large — maximum 200MB per video clip`)
      continue
    }
    
    const previewUrl = URL.createObjectURL(file)
    form.value.media.push({ type: 'video', file, previewUrl })
  }
  
  input.value = ''
}

function removeMedia(index: number) {
  const item = form.value.media[index]
  if (item.type === 'video' && item.previewUrl) {
    URL.revokeObjectURL(item.previewUrl)
  }
  form.value.media.splice(index, 1)
  // Rebuild photos array for backwards compat
  form.value.photos = form.value.media.filter(m => m.type === 'photo').map(m => m.src!)
}

function moveMedia(index: number, direction: -1 | 1) {
  const newIndex = index + direction
  if (newIndex < 0 || newIndex >= form.value.media.length) return
  const temp = form.value.media[index]
  form.value.media[index] = form.value.media[newIndex]
  form.value.media[newIndex] = temp
}

function onMusicUpload(event: Event) {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  if (file) form.value.musicFile = file
  target.value = ''  // ← reset so same or different file can be selected again
}

// ── Build options ─────────────────────────────────────────────────────────────
function buildOptions(watermark: boolean): TributeOptions {
  return {
    media:         form.value.media,
    photos:        form.value.photos,
    name:          form.value.name,
    birthYear:     form.value.birthYear,
    deathYear:     form.value.deathYear,
    tribute:       form.value.tribute,
    musicTrack:    form.value.musicTrack,
    musicFile:     form.value.musicFile,
    slideDuration: form.value.slideDuration,
    transition:    form.value.transition,
    watermark,
  }
}

// ── Payment flow ──────────────────────────────────────────────────────────────
async function handlePreview() {
  if (!turnstileToken.value) { turnstileError.value = true; return }
  track('tribute_preview_started', {
    photoCount: form.value.photos.length,
    musicTrack: form.value.musicTrack,
    transition: form.value.transition,
    slideDuration: form.value.slideDuration,
  })
  const result = await generateTribute(buildOptions(true))
  track(result ? 'tribute_preview_succeeded' : 'tribute_preview_failed', {
    photoCount: form.value.photos.length,
    videoCount: videoCount.value,
  })
  if (result) downloadTribute(result)
}

/*
  Render first, charge second.

  The video is built before the payment modal opens. If it fails, the person
  sees the error and is never asked for money. If it succeeds we hold it in
  memory and hand it over the moment Stripe confirms.
*/
async function handlePurchase() {
  if (!turnstileToken.value) { turnstileError.value = true; return }
  track('tribute_purchase_clicked', {
    photoCount: form.value.photos.length,
    musicTrack: form.value.musicTrack,
  })

  isBuildingForPurchase.value = true
  const result = await generateTribute(buildOptions(false))
  isBuildingForPurchase.value = false

  if (!result) {
    track('tribute_render_failed_before_payment', {
      photoCount: form.value.photos.length,
      videoCount: videoCount.value,
    })
    return // generateTribute has already set `error`
  }

  pendingVideo.value = result
  track('tribute_render_succeeded_before_payment', {
    photoCount: form.value.photos.length,
    videoCount: videoCount.value,
  })
  showPaymentModal.value = true
}

// Modal emits this when it successfully gets a Stripe URL — opens in new tab
function onPaymentOpened(url: string) {
  lastPaymentUrl.value = url
  showPaymentModal.value = false
  showingPaymentPending.value = true
   track('tribute_payment_opened')
}

function reopenPayment() {
  if (lastPaymentUrl.value) window.open(lastPaymentUrl.value, '_blank')
}

/** Abandoning the purchase discards the unpaid clean video rather than leaving it in memory. */
function cancelPayment() {
  showingPaymentPending.value = false
  pendingVideo.value = null
  track('tribute_payment_cancelled')
}

async function verifyAndGenerate(sessionId: string) {
  isVerifying.value = true
  error.value = ''

  try {
    const response = await fetch(`${import.meta.env.VITE_API_BASE_URL}/verify-tribute-payment`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId }),
    })

    const { verified } = await response.json()

    if (!verified) {
        track('tribute_payment_verification_failed')
      error.value = 'Payment could not be verified. Please check your payment was completed and try again.'
      isVerifying.value = false
      return
    }
     track('tribute_payment_success', {
      photoCount: form.value.photos.length,
      musicTrack: form.value.musicTrack,
      transition: form.value.transition,
    })

    hasPaid.value = true
    isVerifying.value = false
    showingPaymentPending.value = false

    // Normal path: the video was built before payment and is waiting.
    if (pendingVideo.value) {
      downloadTribute(pendingVideo.value)
      pendingVideo.value = null
      return
    }

    // Fallback, e.g. the page was reloaded between paying and returning.
    const result = await generateTribute(buildOptions(false))
    if (result) downloadTribute(result)

  } catch {
    error.value = 'Could not verify payment. Please try again.'
    isVerifying.value = false
  }
}
</script>

<style scoped>


.tribute-page { font-family: 'DM Sans', sans-serif; background: #F5F0E8; min-height: 100vh; }

/* Hero */
.tribute-hero { background: #1C1917; padding: 80px 24px 72px; text-align: center; position: relative; overflow: hidden; }
.tribute-hero::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at 50% 0%, rgba(148,116,74,0.15) 0%, transparent 70%); pointer-events: none; }
.tribute-hero-inner { position: relative; max-width: 640px; margin: 0 auto; }
.hero-badge { display: inline-block; font-size: 11px; font-weight: 500; letter-spacing: 0.22em; text-transform: uppercase; color: #9C7C5C; margin-bottom: 20px; }
.hero-title { font-family: 'Playfair Display', Georgia, serif; font-size: clamp(2.2rem, 5vw, 3.5rem); font-weight: 700; color: #F5F0E8; line-height: 1.15; letter-spacing: -0.02em; margin: 0 0 16px; }
.hero-title em { font-style: italic; color: #C4A882; }
.hero-sub { font-size: 16px; line-height: 1.7; color: #A8A29E; margin: 0 0 24px; }
.hero-trust { display: flex; flex-wrap: wrap; justify-content: center; gap: 8px 20px; font-size: 12px; color: #6C6460; }

/* Builder */
.builder-section { padding: 48px 20px 80px; }
.builder-inner { max-width: 680px; margin: 0 auto; }

/* Steps */
/*
  Each step used to be flex: 1, so all four took a quarter of the bar. On a
  phone only the active step shows a label, which left it 82px for a label
  needing ~127px — "Music & style" wrapped to two lines, the pill grew taller
  than the dots, and the rounded bar looked broken. Meanwhile the three plain
  dots sat on space they weren't using.

  Now items size to their content and spread across the bar, so the one step
  with text gets the room it needs. min-height keeps every pill the same height
  whether it holds a label or not.
*/
.steps-bar { display: flex; align-items: center; justify-content: space-between; gap: 4px; margin-bottom: 28px; background: white; border: 1px solid #E8DDD0; border-radius: 100px; padding: 6px; }
.step-item { flex: 0 0 auto; display: flex; align-items: center; gap: 6px; justify-content: center; min-height: 38px; box-sizing: border-box; padding: 8px 12px; border-radius: 100px; cursor: default; transition: all 0.2s; }
.step-active { background: #1C1917; }
.step-done { cursor: pointer; opacity: 0.7; }
.step-dot { width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: 600; flex-shrink: 0; }
.step-active .step-dot { background: #9C7C5C; color: white; }
.step-done .step-dot { background: #7C5C3B; color: white; }
.step-idle .step-dot { background: #F0EBE3; color: #A8A29E; }
.step-label { font-size: 12px; font-weight: 500; color: #1C1917; display: none; white-space: nowrap; }
.step-active .step-label { display: block; color: white; }

/*
  All four labels only once there is genuinely room. The old 500px breakpoint
  was too early: "Details", "Photos", "Music & style" and "Preview & export"
  need about 455px between them, which overflows a 500px screen once page
  padding is taken off.
*/
@media (min-width: 640px) {
  .step-item { flex: 1 1 auto; }
  .step-label { display: block; }
  .step-idle .step-label { color: #A8A29E; }
  .step-done .step-label { color: #7C5C3B; }
}

/* Card */
.builder-card { background: white; border: 1px solid #E8DDD0; border-radius: 28px; padding: 32px; }
.card-title { font-family: 'Playfair Display', Georgia, serif; font-size: 1.6rem; font-weight: 700; color: #1C1917; margin: 0 0 6px; }
.card-sub { font-size: 14px; line-height: 1.6; color: #78716C; margin: 0 0 28px; }

/* Fields */
.field-group { margin-bottom: 20px; }
.field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px; }
.field-label { display: block; font-size: 13px; font-weight: 500; color: #1C1917; margin-bottom: 6px; }
.field-hint { font-size: 11px; color: #A8A29E; margin-top: 2px; margin-bottom: 8px; }
.required { color: #9C7C5C; }
.field-optional { font-weight: 400; color: #A8A29E; }
.field-input { display: block; width: 100%; border: 1.5px solid #E7E5E4; border-radius: 14px; padding: 10px 14px; font-size: 14px; font-family: 'DM Sans', sans-serif; color: #1C1917; background: white; outline: none; transition: border-color 0.15s; box-sizing: border-box; }
.field-input:focus { border-color: #7C5C3B; }
.field-input::placeholder { color: #D6D3D1; }
.field-textarea { resize: vertical; min-height: 100px; }
.field-count { font-size: 11px; color: #A8A29E; text-align: right; margin-top: 4px; }

/* Upload */
.upload-zone { border: 2px dashed #E8DDD0; border-radius: 20px; padding: 40px 24px; text-align: center; cursor: pointer; transition: all 0.15s; margin-bottom: 20px; background: #FAFAF9; }
.upload-zone:hover, .upload-zone-hover { border-color: #7C5C3B; background: #FAF7F4; }
.upload-icon { font-size: 32px; display: block; margin-bottom: 10px; }
.upload-text { font-size: 14px; color: #5C534E; margin: 0 0 4px; }
.upload-link { color: #7C5C3B; text-decoration: underline; }
.upload-hint { font-size: 12px; color: #A8A29E; margin: 0; }

/* Photos */
.photo-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(100px, 1fr)); gap: 10px; margin-bottom: 24px; }
.photo-thumb { position: relative; border-radius: 12px; overflow: hidden; aspect-ratio: 1; border: 1.5px solid #E8DDD0; }
.photo-thumb-first { border-color: #7C5C3B; }
.photo-img { width: 100%; height: 100%; object-fit: cover; display: block; }
.photo-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; gap: 6px; opacity: 0; transition: opacity 0.15s; }
.photo-thumb:hover .photo-overlay { opacity: 1; }
.photo-btn { background: rgba(255,255,255,0.9); border: none; border-radius: 50%; width: 26px; height: 26px; font-size: 12px; cursor: pointer; color: #1C1917; }
.photo-btn-remove { background: rgba(220,38,38,0.85); color: white; }
.photo-first-badge { position: absolute; bottom: 4px; left: 4px; background: #7C5C3B; color: white; font-size: 9px; font-weight: 600; padding: 2px 6px; border-radius: 100px; text-transform: uppercase; }
.photo-empty { font-size: 13px; color: #A8A29E; text-align: center; padding: 20px; }

/* Music */
.option-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 8px; }
.option-card { border: 1.5px solid; border-radius: 16px; padding: 14px 10px; text-align: center; cursor: pointer; transition: all 0.15s; }
.option-active { border-color: #1C1917; background: #1C1917; }
.option-idle { border-color: #E7E5E4; background: white; }
.option-idle:hover { border-color: #A8A29E; }
.option-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
.option-emoji { font-size: 20px; }
.option-label { font-size: 12px; font-weight: 600; color: #1C1917; margin: 0 0 2px; }
.option-active .option-label { color: white; }
.option-desc { font-size: 10px; color: #78716C; margin: 0; }
.option-active .option-desc { color: #9C8C7C; }
.preview-btn { width: 26px; height: 26px; border-radius: 50%; border: 1.5px solid #E7E5E4; background: white; font-size: 9px; cursor: pointer; display: flex; align-items: center; justify-content: center; color: #7C5C3B; transition: all 0.15s; flex-shrink: 0; }
.preview-btn:hover { background: #F5F0E8; border-color: #7C5C3B; }
.preview-btn-playing { background: #7C5C3B; border-color: #7C5C3B; color: white; }
.option-active .preview-btn { border-color: rgba(255,255,255,0.3); color: white; background: rgba(255,255,255,0.15); }
.option-active .preview-btn-playing { background: rgba(255,255,255,0.3); }
.playing-bar { display: flex; align-items: flex-end; gap: 2px; height: 14px; margin-top: 6px; justify-content: center; }
.playing-bar span { display: block; width: 3px; border-radius: 2px; background: currentColor; opacity: 0.6; animation: bar-bounce 0.8s ease-in-out infinite; }
.playing-bar span:nth-child(1) { height: 6px; animation-delay: 0s; }
.playing-bar span:nth-child(2) { height: 12px; animation-delay: 0.15s; }
.playing-bar span:nth-child(3) { height: 8px; animation-delay: 0.3s; }
.playing-bar span:nth-child(4) { height: 10px; animation-delay: 0.45s; }
.option-active .playing-bar span { background: white; opacity: 0.8; }
@keyframes bar-bounce { 0%, 100% { transform: scaleY(0.4); } 50% { transform: scaleY(1); } }
.music-upload-btn { display: inline-block; margin-top: 8px; padding: 10px 18px; border: 1.5px dashed #E7E5E4; border-radius: 12px; font-size: 13px; color: #7C5C3B; cursor: pointer; }

/* Duration */
.duration-row { display: flex; gap: 10px; margin-top: 8px; }
.duration-btn { flex: 1; padding: 12px; border: 1.5px solid; border-radius: 14px; text-align: center; cursor: pointer; transition: all 0.15s; }
.duration-active { border-color: #1C1917; background: #1C1917; }
.duration-idle { border-color: #E7E5E4; background: white; }
.duration-idle:hover { border-color: #A8A29E; }
.duration-num { display: block; font-size: 20px; font-weight: 700; color: #1C1917; }
.duration-active .duration-num { color: white; }
.duration-hint { display: block; font-size: 11px; color: #A8A29E; margin-top: 2px; }
.duration-active .duration-hint { color: #9C8C7C; }

/* Transitions */
.transition-row { display: flex; gap: 10px; margin-top: 8px; }
.transition-btn { flex: 1; padding: 14px 10px; border: 1.5px solid; border-radius: 14px; text-align: center; cursor: pointer; transition: all 0.15s; }
.transition-active { border-color: #1C1917; background: #FAFAF9; }
.transition-idle { border-color: #E7E5E4; background: white; }
.transition-idle:hover { border-color: #A8A29E; }
.transition-preview { height: 28px; border-radius: 6px; overflow: hidden; margin: 0 auto 8px; width: 56px; border: 1px solid #E7E5E4; }
.t-cut { display: flex; height: 100%; }
.t-half-l { flex: 1; background: #C4B8AC; }
.t-half-r { flex: 1; background: #7C5C3B; }
.t-fade { height: 100%; background: linear-gradient(to right, #C4B8AC, #7C5C3B); }
.t-slow-fade { height: 100%; background: linear-gradient(to right, #C4B8AC 20%, #A89880, #7C5C3B 80%); }
.transition-label { font-size: 12px; font-weight: 600; color: #1C1917; margin: 0 0 2px; }
.transition-hint { font-size: 10px; color: #A8A29E; margin: 0; }

/* Estimate */
.estimate-bar { display: flex; align-items: center; justify-content: space-between; background: #F5F0E8; border: 1px solid #E8DDD0; border-radius: 14px; padding: 12px 16px; font-size: 13px; color: #5C534E; margin-top: 20px; }
.estimate-value { font-weight: 600; color: #1C1917; }

/* Summary */
.summary-card { background: #FAFAF9; border: 1px solid #E8DDD0; border-radius: 16px; padding: 16px 20px; margin-bottom: 24px; }
.summary-row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #F0EBE3; font-size: 13px; }
.summary-row:last-child { border-bottom: none; }
.summary-label { color: #78716C; }
.summary-value { font-weight: 500; color: #1C1917; }

/* Turnstile */
.turnstile-wrap { margin-bottom: 16px; min-height: 65px; }

/* Progress */
.progress-section { margin: 20px 0; }
.progress-bar-wrap { height: 6px; background: #F0EBE3; border-radius: 100px; overflow: hidden; margin-bottom: 10px; }
.progress-bar-fill { height: 100%; background: #7C5C3B; border-radius: 100px; transition: width 0.5s ease; }
.progress-row { display: flex; justify-content: space-between; font-size: 13px; color: #5C534E; }
.progress-pct { font-weight: 600; color: #1C1917; }
.progress-note { font-size: 12px; color: #A8A29E; margin-top: 8px; }

/* Payment pending */
.payment-pending-card { background: #F5F0E8; border: 1px solid #E8DDD0; border-radius: 20px; padding: 28px; text-align: center; margin-bottom: 16px; }
.payment-pending-icon { font-size: 36px; margin-bottom: 12px; }
.payment-pending-title { font-family: 'Playfair Display', Georgia, serif; font-size: 1.2rem; font-weight: 700; color: #1C1917; margin: 0 0 8px; }
.payment-pending-desc { font-size: 14px; line-height: 1.7; color: #5C534E; margin: 0; }

/* Export buttons */
.export-buttons { display: flex; flex-direction: column; gap: 12px; margin-bottom: 16px; }
.btn-preview, .btn-purchase { display: flex; align-items: center; gap: 14px; width: 100%; padding: 16px 20px; border-radius: 20px; border: 1.5px solid; cursor: pointer; text-align: left; transition: all 0.15s; }
.btn-preview { border-color: #E7E5E4; background: white; }
.btn-preview:hover { border-color: #A8A29E; }
.btn-purchase { border-color: #1C1917; background: #1C1917; }
.btn-purchase:hover { opacity: 0.9; }
.btn-icon { font-size: 22px; flex-shrink: 0; }
.btn-main-label { font-size: 14px; font-weight: 600; color: #1C1917; margin: 0 0 2px; }
.btn-purchase .btn-main-label { color: white; }
.btn-sub-label { font-size: 12px; color: #78716C; margin: 0; }
.btn-purchase .btn-sub-label { color: #9C8C7C; }
.trust-row { display: flex; flex-wrap: wrap; gap: 6px 10px; justify-content: center; font-size: 11px; color: #A8A29E; margin-bottom: 16px; }

/* Shared buttons */
/*
  Both buttons share a box model so they always match height. They were
  inline-block with different vertical padding (13px vs 12px) and only the
  secondary had a border, so they never quite lined up. min-height also gives
  a 48px touch target, which is the smallest that's comfortable on a phone.
*/
.btn-primary,
.btn-secondary {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  box-sizing: border-box;
  min-height: 48px;
  font-size: 14px;
  font-weight: 500;
  border-radius: 100px;
  cursor: pointer;
  text-align: center;
}
.btn-primary { background: #7C5C3B; color: white; padding: 13px 26px; border: none; transition: opacity 0.2s; width: 100%; }
.btn-primary:hover { opacity: 0.88; }
.btn-primary:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-secondary { background: white; color: #1C1917; padding: 13px 22px; border: 1.5px solid #E7E5E4; transition: all 0.15s; }
.btn-secondary:hover { border-color: #A8A29E; }

.btn-row { display: flex; gap: 10px; margin-top: 24px; align-items: stretch; }
.btn-row .btn-primary { flex: 2; }
.btn-row .btn-secondary { flex: 1; }

/*
  On a phone the 2:1 split left about 210px for the primary button, and
  "Continue — choose music →" needs nearer 230px. It wrapped to two lines, the
  primary grew taller, and the stretched "← Back" became a tall empty pill
  beside it. Stacking avoids the squeeze entirely.

  column-reverse puts the primary action on top — it's the one people want,
  and it sits closest to the thumb.
*/
@media (max-width: 480px) {
  .btn-row { flex-direction: column-reverse; gap: 12px; }
  .btn-row .btn-primary,
  .btn-row .btn-secondary { flex: 0 0 auto; width: 100%; }
}
.btn-back-link { background: none; border: none; font-size: 13px; color: #A8A29E; cursor: pointer; padding: 0; }
.btn-back-link:hover { color: #5C534E; }
.error-text { font-size: 13px; color: #DC2626; background: #FEF2F2; border: 1px solid #FECACA; border-radius: 12px; padding: 10px 14px; margin-bottom: 16px; }

/* Why section */
.why-section { background: #1C1917; padding: 64px 24px 80px; }
.why-inner { max-width: 800px; margin: 0 auto; text-align: center; }
.why-eyebrow { font-size: 11px; font-weight: 500; letter-spacing: 0.22em; text-transform: uppercase; color: #9C7C5C; margin: 0 0 12px; }
.why-title { font-family: 'Playfair Display', Georgia, serif; font-size: clamp(1.6rem, 3vw, 2.2rem); font-weight: 700; color: #F5F0E8; margin: 0 0 32px; }
.why-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 40px; }
@media (min-width: 600px) { .why-grid { grid-template-columns: repeat(4, 1fr); } }
.why-card { background: #2C2420; border: 1px solid #3C3430; border-radius: 20px; padding: 20px 16px; }
.why-icon { font-size: 24px; display: block; margin-bottom: 10px; }
.why-card-title { font-size: 13px; font-weight: 600; color: #E8DDD0; margin: 0 0 6px; }
.why-card-desc { font-size: 12px; line-height: 1.6; color: #6C6460; margin: 0; }
.upsell-card { background: #2C2420; border: 1px solid #3C3430; border-radius: 24px; padding: 32px; text-align: left; }
.upsell-eyebrow { font-size: 11px; font-weight: 500; letter-spacing: 0.2em; text-transform: uppercase; color: #9C7C5C; margin: 0 0 10px; }
.upsell-title { font-family: 'Playfair Display', Georgia, serif; font-size: 1.4rem; font-weight: 700; color: #F5F0E8; margin: 0 0 12px; line-height: 1.25; }
.upsell-desc { font-size: 14px; line-height: 1.7; color: #8C847E; margin: 0 0 20px; }
.upsell-btn { display: inline-block; background: #7C5C3B; color: white; font-size: 13px; font-weight: 500; padding: 11px 22px; border-radius: 100px; text-decoration: none; transition: opacity 0.2s; }
.upsell-btn:hover { opacity: 0.88; }
.hidden { display: none; }

.verifying-row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  margin-top: 16px;
  font-size: 14px;
  color: #5C534E;
}

.spinner {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid #E8DDD0;
  border-top-color: #7C5C3B;
  animation: spin 0.8s linear infinite;
  flex-shrink: 0;
}

.upload-btn-row {
  display: flex;
  gap: 12px;
  margin-top: 12px;
  flex-wrap: wrap;
  justify-content: center;
}

.upload-type-btn {
  cursor: pointer;
  background: white;
  border: 1px solid #E8DDD0;
  border-radius: 999px;
  padding: 8px 20px;
  font-size: 13px;
  font-weight: 500;
  color: #1C1917;
  transition: background 0.15s;
}

.upload-type-btn:hover {
  background: #F5F0E8;
}

.upload-type-btn-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.photo-thumb-video {
  border: 2px solid #7C5C3B;
}

.video-thumb-inner {
  position: relative;
  width: 100%;
  height: 100%;
}

.video-badge {
  position: absolute;
  bottom: 6px;
  left: 6px;
  background: rgba(28,25,23,0.75);
  color: white;
  font-size: 10px;
  font-weight: 600;
  padding: 2px 8px;
  border-radius: 999px;
}

.media-counts {
  margin-top: 8px;
  font-size: 12px;
  color: #8C847E;
  display: flex;
  gap: 8px;
}

@keyframes spin { to { transform: rotate(360deg); } }

</style>