<template>
  <div>
    <Transition name="fade-slide" mode="out-in">
      <div
        v-if="section"
        :key="section.id"
        class="relative overflow-hidden rounded-2xl border border-stone-200 bg-white"
      >

        <!-- Reading progress — hairline at the very top -->
        <div class="absolute inset-x-0 top-0 z-10 h-[3px] bg-stone-100">
          <div
            class="h-full bg-[#7C5C3B] transition-all duration-700"
            :style="{ width: progress + '%' }"
          />
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- QUESTION — the hero of the screen                          -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="px-6 pb-6 pt-8 sm:px-10 sm:pt-10">
          <div class="flex items-start justify-between gap-6">
            <div class="min-w-0 flex-1">
              <p class="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#9C7C5C]">
                {{ section.chapter || 'Chapter' }}
              </p>
              <h2 class="mt-3 font-display text-[22px] font-semibold leading-[1.35] tracking-[-0.01em] text-stone-900 sm:text-[26px]">
                {{ section.question }}
              </h2>
            </div>

            <!-- Save state — quiet, top right -->
            <p class="mt-1 flex-shrink-0 text-[11px] text-stone-300">
              {{ saveStatus || lastSavedLabel }}
            </p>
          </div>

          <p v-if="saveError" class="mt-3 text-xs text-red-600">{{ saveError }}</p>
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- WRITING SURFACE — feels like a page, not a form            -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="px-6 sm:px-10">

          <!-- Recording indicator -->
          <Transition name="fade">
            <div
              v-if="voiceRecording.isRecording.value"
              class="mb-3 flex items-center gap-2"
            >
              <span class="inline-block h-2 w-2 animate-pulse rounded-full bg-red-500" aria-hidden="true" />
              <p class="text-sm font-medium text-red-600" role="status">
                Recording {{ formatClock(voiceRecording.elapsedSeconds.value) }} — speak naturally, tap Stop when you're done
              </p>
            </div>
            <p
              v-else-if="voiceRecording.isTranscribing.value"
              class="mb-3 text-sm text-stone-500"
              role="status"
            >Typing up what you said…</p>
          </Transition>

          <textarea
            ref="textareaRef"
            :value="voiceRecording.isRecording.value ? voiceRecording.liveTranscript.value : section.answer"
            @input="onAnswerInput"
            class="prose-answer min-h-[260px] w-full resize-none border-0 bg-transparent p-0 focus:outline-none focus:ring-0 sm:min-h-[300px]"
            :class="voiceRecording.isRecording.value ? 'text-stone-500' : 'text-stone-800'"
            rows="10"
            :placeholder="voiceRecording.isRecording.value
              ? 'Your words will appear here when you stop…'
              : 'Start wherever feels natural. There is no wrong way to tell it.'"
            :readonly="voiceRecording.isRecording.value"
          />

          <!-- Microphone problems: explain how to fix it, and offer typing -->
          <div
            v-if="voiceRecording.errorCode.value"
            class="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm leading-relaxed text-stone-700"
            role="alert"
          >
            <p class="font-semibold text-stone-900">{{ voiceRecording.error.value }}</p>
            <template v-if="voiceRecording.errorCode.value === 'denied'">
              <p class="mt-2">To turn it back on:</p>
              <ul class="mt-1 list-disc space-y-1 pl-5">
                <li v-for="step in micHelpSteps" :key="step">{{ step }}</li>
              </ul>
              <p class="mt-2">Then come back and tap Speak again.</p>
            </template>
            <div class="mt-3 flex flex-wrap gap-2">
              <button
                v-if="voiceRecording.errorCode.value !== 'unsupported' && voiceRecording.errorCode.value !== 'insecure'"
                type="button"
                class="min-h-[44px] rounded-full bg-[#7C5C3B] px-5 text-sm font-semibold text-white transition hover:opacity-90"
                @click="handleVoiceToggle"
              >Try again</button>
              <button
                type="button"
                class="min-h-[44px] rounded-full border border-stone-300 bg-white px-5 text-sm font-medium text-stone-800 transition hover:bg-stone-50"
                @click="typeInstead"
              >Type instead</button>
            </div>
          </div>

          <!-- Recording saved but couldn't be typed up -->
          <p v-if="transcriptionNotice" class="mt-3 rounded-xl bg-[#FAF7F4] p-3 text-sm leading-relaxed text-stone-600" role="status">
            {{ transcriptionNotice }}
          </p>

          <!-- Word count + voice button -->
          <div class="mt-4 flex items-center justify-between border-t border-stone-100 pt-4">
            <p class="text-sm text-stone-400">
              <template v-if="wordCount">{{ wordCount }} {{ wordCount === 1 ? 'word' : 'words' }}</template>
              <template v-else-if="voiceRecording.speechSupported">
                Type, or tap Speak to talk it through
              </template>
              <template v-else>Type your answer</template>
            </p>

            <div class="flex items-center gap-2">
              <span
                v-if="existingRecording && !voiceRecording.isRecording.value"
                class="hidden text-[11px] text-[#4A7C59] sm:inline"
              >Voice saved</span>

              <button
                v-if="voiceRecording.speechSupported"
                type="button"
                @click="handleVoiceToggle"
                :disabled="voiceRecording.isSaving.value || voiceRecording.isTranscribing.value"
                class="inline-flex min-h-[48px] items-center gap-2 rounded-full border px-5 text-sm font-semibold transition disabled:opacity-40"
                :class="voiceRecording.isRecording.value
                  ? 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100'
                  : 'border-stone-200 text-stone-700 hover:border-[#7C5C3B] hover:text-[#7C5C3B]'"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M12 1a4 4 0 0 1 4 4v6a4 4 0 0 1-8 0V5a4 4 0 0 1 4-4zm0 2a2 2 0 0 0-2 2v6a2 2 0 0 0 4 0V5a2 2 0 0 0-2-2zm-1 14.93V20H9v2h6v-2h-2v-2.07A8 8 0 0 0 20 11h-2a6 6 0 0 1-12 0H4a8 8 0 0 0 7 7.93z"/>
                </svg>
                {{ voiceRecording.isRecording.value ? 'Stop' : existingRecording ? 'Re-record' : 'Speak' }}
              </button>
            </div>
          </div>
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- VOICE PLAYER                                               -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div
          v-if="existingRecording && !voiceRecording.isRecording.value"
          class="mx-6 mt-5 rounded-xl bg-[#FAF7F4] p-4 sm:mx-10"
        >
          <div class="flex items-center gap-4">
            <button
              type="button"
              @click="toggleExistingPlayback"
              class="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-full bg-[#7C5C3B] text-white transition hover:opacity-90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1C1917] focus-visible:ring-offset-2"
              :aria-label="isPlayingExisting ? 'Pause the recording' : 'Play the recording for this question'"
            >
              <svg v-if="!isPlayingExisting" xmlns="http://www.w3.org/2000/svg" class="ml-0.5 h-4 w-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>
              <svg v-else xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
            </button>

            <div class="min-w-0 flex-1">
              <div
                class="h-1.5 w-full overflow-hidden rounded-full bg-[#E8DDD0]"
                role="progressbar"
                aria-label="Playback position"
                aria-valuemin="0"
                aria-valuemax="100"
                :aria-valuenow="Math.round(existingProgress)"
              >
                <div class="h-full rounded-full bg-[#7C5C3B] transition-all" :style="{ width: `${existingProgress}%` }" />
              </div>
              <div class="mt-2 flex items-center justify-between gap-3">
                <p class="text-xs text-stone-500">
                  {{ formatClock(Math.floor(existingCurrentTime)) }} / {{ formatClock(Math.round(existingDuration || existingRecording.duration_seconds || 0)) }}
                </p>
                <!-- Whole row is the tap target, not just the tiny switch -->
                <button
                  type="button"
                  role="switch"
                  :aria-checked="!!existingRecording.show_qr"
                  aria-label="Print a QR code for this recording in the book"
                  class="flex min-h-[44px] items-center gap-2 rounded-full px-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7C5C3B]"
                  @click="toggleQR"
                >
                  <span class="text-xs text-stone-600">QR in book</span>
                  <span
                    class="relative inline-flex h-5 w-9 flex-shrink-0 rounded-full transition-colors duration-200"
                    :class="existingRecording.show_qr ? 'bg-[#7C5C3B]' : 'bg-stone-300'"
                    aria-hidden="true"
                  >
                    <span
                      class="mt-0.5 ml-0.5 inline-block h-4 w-4 transform rounded-full bg-white shadow transition duration-200"
                      :class="existingRecording.show_qr ? 'translate-x-4' : 'translate-x-0'"
                    />
                  </span>
                </button>
              </div>
            </div>

            <canvas ref="qrCanvas" class="hidden flex-shrink-0 rounded sm:block" width="48" height="48" aria-hidden="true" />

            <button
              type="button"
              @click="deleteExistingRecording"
              class="min-h-[44px] flex-shrink-0 rounded-full px-2 text-xs text-stone-500 transition hover:text-red-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-400"
              aria-label="Remove this voice recording"
            >Remove</button>
          </div>

          <audio
            ref="existingAudioRef"
            :src="existingRecording.audio_url"
            @timeupdate="onExistingTimeUpdate"
            @loadedmetadata="onExistingMetadata"
            @ended="isPlayingExisting = false"
            preload="metadata"
          />
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- TOOLS — one quiet row                                      -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="px-6 pt-5 sm:px-10">
          <div class="flex flex-wrap items-center gap-2">

            <button
              v-if="!section?.answer?.trim() || section.answer.trim().length <= 20"
              type="button"
              @click="fetchWritingAssist('start')"
              :disabled="writingAssistLoading"
              class="tool-btn"
            >Help me start</button>

            <button
              v-else-if="!writingAssistLoading"
              type="button"
              @click="fetchWritingAssist('expand')"
              class="tool-btn"
            >Help me add more</button>

            <span v-if="writingAssistLoading" class="inline-flex items-center gap-2 text-xs text-stone-400">
              <span class="inline-block h-3 w-3 animate-spin rounded-full border-2 border-stone-200 border-t-[#7C5C3B]" />
              Thinking…
            </span>

            <button
              type="button"
              @click="$emit('toggle-highlight')"
              class="tool-btn"
              :class="isHighlighted ? 'border-[#7C5C3B] bg-[#FAF7F4] text-[#7C5C3B]' : ''"
            >
              {{ isHighlighted ? 'Highlighted' : 'Highlight this memory' }}
            </button>

            <!-- Photo — inline, not a whole section -->
            <label v-if="!currentImagePreview" class="tool-btn cursor-pointer">
              Add a photo
              <input type="file" accept="image/*" @change="$emit('image-upload', $event)" class="hidden" />
            </label>

            <button
              v-if="commentCount > 0"
              @click="showComments = !showComments"
              class="tool-btn border-[#7C5C3B]/30 text-[#7C5C3B]"
            >
              {{ commentCount }} family comment{{ commentCount === 1 ? '' : 's' }}
            </button>
          </div>

          <p v-if="writingAssistError" class="mt-3 text-xs text-red-500">{{ writingAssistError }}</p>

          <!-- Writing assist output -->
          <Transition name="fade">
            <div v-if="writingAssistSuggestions.length" class="mt-4 rounded-xl bg-[#FAF7F4] p-5">
              <div class="flex items-start justify-between gap-4">
                <div>
                  <p class="text-xs font-semibold text-stone-800">Things you might add</p>
                  <p class="mt-0.5 text-[11px] text-stone-500">Prompts only — keep writing in your own words</p>
                </div>
                <button
                  @click="writingAssistSuggestions = []"
                  class="flex-shrink-0 text-[11px] text-stone-400 hover:text-stone-600"
                >Dismiss</button>
              </div>
              <ul class="mt-4 space-y-2.5">
                <li
                  v-for="(suggestion, i) in writingAssistSuggestions"
                  :key="i"
                  class="flex gap-3 text-[13px] leading-relaxed text-stone-700"
                >
                  <span class="mt-[7px] h-1 w-1 flex-shrink-0 rounded-full bg-[#9C7C5C]" />
                  {{ suggestion }}
                </li>
              </ul>
            </div>
          </Transition>

          <!-- Family comments -->
          <Transition name="fade">
            <div v-if="showComments && commentCount > 0" class="mt-4 rounded-xl bg-[#FAF7F4] p-5">
              <p class="text-xs font-semibold text-stone-800">What family said about this answer</p>
              <div class="mt-4 space-y-4">
                <div v-for="comment in sectionComments" :key="comment.id" class="flex gap-3">
                  <div class="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-[#E8DDD0] text-[11px] font-semibold text-[#7C5C3B]">
                    {{ comment.author_name.charAt(0).toUpperCase() }}
                  </div>
                  <div>
                    <p class="text-xs font-semibold text-stone-800">{{ comment.author_name }}</p>
                    <p class="mt-0.5 text-[13px] leading-relaxed text-stone-600">{{ comment.comment }}</p>
                  </div>
                </div>
              </div>
            </div>
          </Transition>

          <!-- Photo preview -->
          <div v-if="currentImagePreview && currentImagePreview.length > 0" class="mt-4">
            <div class="relative overflow-hidden rounded-xl">
              <img
                :src="currentImagePreview"
                alt="Story photo"
                class="max-h-64 w-full object-cover"
                @error="$emit('image-error')"
              />
              <div
                v-if="!hasImageExportAccess"
                class="absolute right-3 top-3 rounded-full bg-black/60 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-wide text-white backdrop-blur"
              >Premium</div>
            </div>
            <div class="mt-2.5 flex flex-wrap items-center gap-2">
              <label class="tool-btn cursor-pointer">
                Replace
                <input type="file" accept="image/*" @change="$emit('image-upload', $event)" class="hidden" />
              </label>
              <button @click="$emit('remove-image')" class="tool-btn hover:border-red-200 hover:text-red-500">
                Remove
              </button>
              <p v-if="!hasImageExportAccess" class="text-[11px] text-stone-500">
                Saved —
                <button @click="$emit('upgrade-images')" class="font-semibold text-[#7C5C3B] underline">
                  upgrade to include it in your keepsake
                </button>
              </p>
            </div>
          </div>

          <p v-if="imageUploadStatus" class="mt-2 text-xs text-stone-500">{{ imageUploadStatus }}</p>
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- COMPLETION                                                 -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div v-if="progress === 100" class="mx-6 mt-6 rounded-2xl bg-[#2C2420] p-6 text-center sm:mx-10">
          <p class="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#C4A882]">Story complete</p>
          <p class="mt-3 font-display text-xl font-semibold text-white">
            You've created something worth keeping
          </p>
          <p class="mt-2 text-sm leading-relaxed text-stone-400">
            Every answer is saved. It's ready to become a finished keepsake.
          </p>
          <div class="mt-5 flex flex-col items-center gap-2.5">
            <button
              @click="$emit('finish')"
              class="rounded-full bg-[#7C5C3B] px-7 py-3 text-sm font-semibold text-white transition hover:opacity-90"
            >Create my keepsake</button>
            <button
              v-if="!hasImageExportAccess"
              @click="$emit('upgrade-images')"
              class="text-xs text-stone-400 transition hover:text-white"
            >Add photos and premium layouts</button>
          </div>
        </div>

        <!-- ══════════════════════════════════════════════════════════ -->
        <!-- NAVIGATION                                                 -->
        <!-- ══════════════════════════════════════════════════════════ -->
        <div class="sticky bottom-0 mt-6 border-t border-stone-100 bg-white/90 px-6 py-3.5 backdrop-blur-sm sm:px-10">
          <div class="flex items-center justify-between gap-3">
            <button
              @click="handlePreviousClick"
              :disabled="currentIndex === 0 || voiceRecording.isTranscribing.value || voiceRecording.isSaving.value"
              class="min-h-[44px] rounded-full px-4 text-sm font-medium text-stone-500 transition hover:bg-stone-50 hover:text-stone-800 disabled:pointer-events-none disabled:opacity-25"
            >
              ← Previous
            </button>

            <span class="font-display text-sm text-stone-500">
              Question {{ currentIndex + 1 }} <span class="text-stone-400">of</span> {{ totalSections }}
            </span>

            <button
              @click="handleNextClick"
              :disabled="voiceRecording.isTranscribing.value || voiceRecording.isSaving.value"
              class="min-h-[44px] rounded-full bg-[#7C5C3B] px-6 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-50"
            >
              {{ currentIndex === totalSections - 1 ? 'Finish' : 'Next' }} →
            </button>
          </div>
        </div>

      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, nextTick, onUnmounted, computed } from 'vue'
import type { StorySection } from '../../types/story'
import { useVoiceRecording } from '../../lib/useVoiceRecording_whisper'
import type { VoiceRecording } from '../../lib/useVoiceRecording_whisper'
import QRCode from 'qrcode'
import { supabase } from '../../lib/supabase'

const props = defineProps<{
  section: StorySection | null
  currentIndex: number
  totalSections: number
  progress: number
  progressMessage: string
  saveStatus: string
  saveError: string
  lastSavedLabel: string
  currentImagePreview: string
  imageUploadStatus: string
  hasImageExportAccess: boolean
  isHighlighted: boolean
  projectId: string
}>()

const emit = defineEmits<{
  (e: 'update-answer', value: string): void
  (e: 'image-upload', event: Event): void
  (e: 'remove-image'): void
  (e: 'upgrade-images'): void
  (e: 'export-pdf'): void
  (e: 'previous'): void
  (e: 'next'): void
  (e: 'finish'): void
  (e: 'image-error'): void
  (e: 'toggle-highlight'): void
}>()

const textareaRef       = ref<HTMLTextAreaElement | null>(null)
const existingRecording = ref<VoiceRecording | null>(null)
const qrCanvas          = ref<HTMLCanvasElement | null>(null)
const existingAudioRef  = ref<HTMLAudioElement | null>(null)
const isPlayingExisting = ref(false)
const existingCurrentTime = ref(0)
const existingDuration    = ref(0)
const existingProgress    = ref(0)

const writingAssistLoading     = ref(false)
const writingAssistSuggestions = ref<string[]>([])
const writingAssistError       = ref('')

const sectionComments = ref<any[]>([])
const showComments    = ref(false)
const commentCount    = computed(() => sectionComments.value.length)

const voiceRecording = useVoiceRecording()

const wordCount = computed(() => {
  const text = props.section?.answer?.trim()
  if (!text) return 0
  return text.split(/\s+/).filter(Boolean).length
})

async function toggleQR() {
  if (!existingRecording.value) return
  const newValue = !existingRecording.value.show_qr
  await supabase.from('voice_recordings').update({ show_qr: newValue }).eq('id', existingRecording.value.id)
  existingRecording.value = { ...existingRecording.value, show_qr: newValue }
}

async function loadSectionComments() {
  if (!props.section || !props.projectId) return
  const { data } = await supabase
    .from('story_comments').select('*')
    .eq('project_id', props.projectId)
    .eq('section_id', props.section.id)
    .order('created_at', { ascending: true })
  sectionComments.value = data || []
}

async function loadExistingRecording() {
  if (!props.section || !props.projectId) return
  existingRecording.value = await voiceRecording.loadRecording(props.section.id, props.projectId)
}

async function fetchWritingAssist(mode: 'start' | 'expand') {
  if (!props.section?.question) return
  writingAssistLoading.value = true
  writingAssistSuggestions.value = []
  writingAssistError.value = ''
  try {
    const response = await fetch('https://tellmeyourstoryimproved.onrender.com/writing-assist', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question: props.section.question, answer: props.section.answer || '', mode }),
    })
    const data = await response.json()
    if (!response.ok || !data.suggestions) { writingAssistError.value = 'Could not load suggestions. Please try again.'; return }
    writingAssistSuggestions.value = data.suggestions
  } catch {
    writingAssistError.value = 'Could not reach the writing assistant. Please try again.'
  } finally {
    writingAssistLoading.value = false
  }
}

async function generateQRCode(recordingId: string) {
  if (!qrCanvas.value) return
  const url = `${window.location.origin}/listen/${recordingId}`
  try {
    await QRCode.toCanvas(qrCanvas.value, url, { width: 56, margin: 1, color: { dark: '#1C1917', light: '#F0FDF4' } })
  } catch (err) {
    console.error('QR generation error:', err)
  }
}

watch(
  () => existingRecording.value?.id,
  async (id) => {
    if (!id) return
    await nextTick()
    await new Promise(resolve => setTimeout(resolve, 50))
    await generateQRCode(id)
  },
  { flush: 'post' }
)

// What the answer looked like when recording started, so a new recording
// adds to typed text instead of wiping it.
const answerBeforeRecording = ref('')
const transcriptBeforeRecording = ref('')
const transcriptionNotice = ref('')

/**
 * Combine the new transcript with what was already there:
 *  - empty answer            → just the transcript
 *  - answer was the previous
 *    recording's transcript  → replace it (a re-record)
 *  - anything else (typed)   → keep it and add the transcript underneath
 */
function mergeAnswer(before: string, previousTranscript: string, transcript: string) {
  const b = before.trim()
  if (!b) return transcript
  if (previousTranscript && b === previousTranscript.trim()) return transcript
  return `${b}\n\n${transcript}`
}

async function handleVoiceToggle() {
  transcriptionNotice.value = ''

  if (voiceRecording.isRecording.value) {
    const section = props.section
    const result = await voiceRecording.stopRecording()
    if (!result || !section) return

    if (!result.transcriptionFailed) {
      emit('update-answer', mergeAnswer(answerBeforeRecording.value, transcriptBeforeRecording.value, result.transcript))
    } else {
      transcriptionNotice.value = "Your recording is saved, but we couldn't type it up this time. You can type the answer yourself, or record it again."
    }

    const saved = await voiceRecording.saveRecording(
      result.blob,
      result.transcript,
      result.durationSeconds,
      section.id,
      props.projectId,
    )
    if (saved) {
      existingRecording.value = null
      await nextTick()
      existingRecording.value = saved
      await nextTick()
      await new Promise(resolve => setTimeout(resolve, 100))
    }
  } else {
    answerBeforeRecording.value = props.section?.answer || ''
    transcriptBeforeRecording.value = existingRecording.value?.transcript || ''
    await voiceRecording.startRecording(props.section?.answer || '')
  }
}

/**
 * Called by the editor before ANY navigation (next, previous, story map),
 * so a recording in progress is saved to this question instead of lost.
 */
async function finishRecordingIfActive() {
  if (voiceRecording.isRecording.value) await handleVoiceToggle()
}

defineExpose({ finishRecordingIfActive })

function typeInstead() {
  voiceRecording.clearError()
  textareaRef.value?.focus()
}

function formatClock(seconds: number) {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${s.toString().padStart(2, '0')}`
}

// Device-specific steps for re-enabling the microphone
const micHelpSteps = computed(() => {
  const ua = navigator.userAgent
  if (/iPhone|iPad|iPod/.test(ua)) {
    return [
      'Tap "aA" (or the icon) on the left of the address bar, then Website Settings',
      'Set Microphone to Allow',
      'If that does not appear: Settings app → Safari → Microphone → Allow',
    ]
  }
  if (/Android/.test(ua)) {
    return [
      'Tap the icon on the left of the address bar',
      'Tap Permissions (or Site settings) → Microphone → Allow',
    ]
  }
  return [
    'Click the icon on the left of the address bar',
    'Set Microphone to Allow, then refresh the page',
  ]
})

function toggleExistingPlayback() {
  if (!existingAudioRef.value) return
  if (isPlayingExisting.value) { existingAudioRef.value.pause(); isPlayingExisting.value = false }
  else { existingAudioRef.value.play(); isPlayingExisting.value = true }
}

function onExistingTimeUpdate() {
  if (!existingAudioRef.value) return
  existingCurrentTime.value = existingAudioRef.value.currentTime
  existingProgress.value = existingDuration.value ? (existingCurrentTime.value / existingDuration.value) * 100 : 0
}

function onExistingMetadata() {
  if (existingAudioRef.value) existingDuration.value = existingAudioRef.value.duration
}

async function deleteExistingRecording() {
  if (!props.section || !confirm('Remove this voice recording?')) return
  await voiceRecording.deleteRecording(props.section.id, props.projectId)
  existingRecording.value = null
  isPlayingExisting.value = false
}

function onAnswerInput(event: Event) {
  const target = event.target as HTMLTextAreaElement
  emit('update-answer', target.value)
}

// Save any recording in progress before moving on (it used to be discarded).
async function handleNextClick() {
  await finishRecordingIfActive()
  if (props.currentIndex === props.totalSections - 1) emit('finish')
  else emit('next')
}

async function handlePreviousClick() {
  await finishRecordingIfActive()
  emit('previous')
}

watch(
  () => props.section?.id,
  async () => {
    // Safety net only — the editor saves recordings before navigating.
    if (voiceRecording.isRecording.value) voiceRecording.cancelRecording()
    voiceRecording.clearError()
    transcriptionNotice.value = ''
    existingRecording.value = null
    writingAssistSuggestions.value = []
    writingAssistError.value = ''
    sectionComments.value = []
    showComments.value = false
    await loadSectionComments()
    isPlayingExisting.value = false
    await nextTick()
    textareaRef.value?.focus()
    await new Promise(resolve => setTimeout(resolve, 280))
    await loadExistingRecording()
  },
  { immediate: true }
)

onUnmounted(() => { voiceRecording.cancelRecording() })
</script>

<style scoped>
.font-display {
  font-family: 'Playfair Display', Georgia, serif;
}

/* The writing surface — a page, not a form field */
.prose-answer {
  font-family: 'Lora', Georgia, serif;
  font-size: 18px;
  line-height: 1.9;
  letter-spacing: 0.005em;
}
.prose-answer::placeholder {
  color: #C4BEB8;
  font-style: italic;
}

/* Quiet secondary buttons */
.tool-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.375rem;
  border-radius: 9999px;
  border: 1px solid #E7E5E4;
  background: #fff;
  padding: 0.4rem 0.85rem;
  font-size: 12px;
  font-weight: 500;
  color: #57534E;
  transition: all 0.2s ease;
}
.tool-btn:hover {
  border-color: #7C5C3B;
  color: #7C5C3B;
}
.tool-btn:disabled {
  opacity: 0.4;
  pointer-events: none;
}

.fade-enter-active,
.fade-leave-active { transition: opacity 0.25s ease; }
.fade-enter-from,
.fade-leave-to { opacity: 0; }

.fade-slide-enter-active,
.fade-slide-leave-active {
  transition: opacity 0.3s ease, transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.fade-slide-enter-from { opacity: 0; transform: translateY(12px); }
.fade-slide-leave-to { opacity: 0; transform: translateY(-8px); }
</style>